#version 120

#define NETHER_SHADER

#define ENTITIES
#define BLOCKENTITIES

#include "/dimensions/clrwl_translucent.vsh"
