#version 120

#define NETHER_SHADER

#define WORLD
#define ENTITIES
#define BLOCKENTITIES

#include "/dimensions/clrwl_solid.vsh"
