#version 120

#define DAMAGE_BLOCK_EFFECT
#define END_SHADER

#include "/dimensions/clrwl_damagedblock.fsh"
